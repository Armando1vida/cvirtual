    public function filters()
    {
        return array(
            array('auth.filters.AuthFilter'),
        );
    }

